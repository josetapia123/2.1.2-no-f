package com.mycompany.ejercicio_2_1_2a;

/**
 *
 * @author tapia
 */
public class Habitacion {
    private Integer numeroHabitacion;
    private String precioNoche;
    private Boolean disponible;

    public Habitacion() {
    }

    public Habitacion(Integer numeroHabitacion, String precioNoche, Boolean disponible) {
        this.numeroHabitacion = numeroHabitacion;
        this.precioNoche = precioNoche;
        this.disponible = disponible;
    }

    public Integer getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public void setNumeroHabitacion(Integer numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public String getPrecioNoche() {
        return precioNoche;
    }

    public void setPrecioNoche(String precioNoche) {
        this.precioNoche = precioNoche;
    }

    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }
    
    
}
