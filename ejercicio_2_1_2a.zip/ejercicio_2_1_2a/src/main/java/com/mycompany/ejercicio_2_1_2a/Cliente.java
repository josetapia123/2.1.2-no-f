package com.mycompany.ejercicio_2_1_2a;

import java.util.ArrayList;

/**
 *
 * @author tapia
 */
public class Cliente {
    private String idCliente;
    private String nombreC;
    private ArrayList reservasRealizadas;

    public Cliente() {
    }

    public Cliente(String idCliente, String nombreC, ArrayList reservasRealizadas) {
        this.idCliente = idCliente;
        this.nombreC = nombreC;
        this.reservasRealizadas = reservasRealizadas;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreC() {
        return nombreC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public ArrayList getReservasRealizadas() {
        return reservasRealizadas;
    }

    public void setReservasRealizadas(ArrayList reservasRealizadas) {
        this.reservasRealizadas = reservasRealizadas;
    }
    
    
}
