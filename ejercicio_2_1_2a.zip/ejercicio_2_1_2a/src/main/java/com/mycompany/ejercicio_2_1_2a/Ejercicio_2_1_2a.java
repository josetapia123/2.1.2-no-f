package com.mycompany.ejercicio_2_1_2a;

/**
 *
 * @author tapia
 */
import java.util.ArrayList;
import java.util.Scanner;
public class Ejercicio_2_1_2a {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        ArrayList<Reserva> reserv = new ArrayList<>();
        
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        
        Hotel hotel_1 = new Hotel("1110f", "Hotel Juan Carlos", null);
        ArrayList<Integer> habitacionesDisponibles_h1 = new ArrayList<>();
        habitacionesDisponibles_h1.add(001);
        habitacionesDisponibles_h1.add(002);
        habitacionesDisponibles_h1.add(003);
        habitacionesDisponibles_h1.add(004);
        hotel_1.setHabitacionesDisponibles(habitacionesDisponibles_h1);
        
        Hotel hotel_2 = new Hotel("0104D", "Hotel Maricarmen", null);
        ArrayList<Integer> habitacionesDisponibles_h2 = new ArrayList<>();
        habitacionesDisponibles_h2.add(120);
        habitacionesDisponibles_h2.add(030);
        habitacionesDisponibles_h2.add(033);
        habitacionesDisponibles_h2.add(047);
        hotel_2.setHabitacionesDisponibles(habitacionesDisponibles_h2);
        
        
        while (true){
        System.out.println("--- Systema de reserva hotel ---\n");
        System.out.println("1. Ver hoteles disponibles");
        System.out.println("2. Buscar habitacion");
        System.out.println("3. Registrar cliente");
        System.out.println("4. Registrar reserva de cliente");
        System.out.println("5. Mostrar detalles de reserva");
        System.out.println("6. Salir\n");
        
        
        System.out.print("Seleccione una opcion (1-6): ");
        Integer opcion = input.nextInt();
        input.nextLine();
        
            switch (opcion){
                case 1:
                    System.out.println("Los hoteles disponibles son:\n" 
                    + hotel_1.getNombreH() + "\n" + hotel_2.getNombreH() + "\n");
                    break;
                
                case 2:
                    System.out.println("Seleccione hotel para ver las habitaciones disponibles:");
                    System.out.println("1. " + hotel_1.getNombreH());
                    System.out.println("2. " + hotel_2.getNombreH());
                    
                    Integer opHD = input.nextInt();
                    input.nextLine();
                    
                    switch (opHD){
                        case 1:
                            System.out.println("Habitaciones disponibles:");
                            System.out.println(hotel_1.getHabitacionesDisponibles());
                            break;
                        
                        case 2:
                            System.out.println("Habitaciones disponibles:");
                            System.out.println(hotel_2.getHabitacionesDisponibles());
                            break;
                            
                    }
                    break;
                case 3:
                    Cliente client = new Cliente();
                    System.out.print("Ingrese el id del cliente: ");
                    client.setIdCliente(input.nextLine());
                    
                    System.out.print("Ingrese el nombre del cliente: ");
                    client.setNombreC(input.nextLine());
                    
                    listaClientes.add(client);
                    System.out.println("El cliente se ha agregado correctamente.\n");
                    break;
                    
                case 4:
                    System.out.println("Los hoteles disponibles son:\n" 
                    + "1. " + hotel_1.getNombreH() + "\n" + "2. " + hotel_2.getNombreH() + "\n");
                    
                    System.out.print("Seleccionar hotel: ");
                    Integer select_hotel = input.nextInt();
                    input.nextLine();
                    
                    switch (select_hotel){
                        case 1:
                            System.out.print("Clientes (ID) disponibles:\n");
                            for (Integer i = 0; i < listaClientes.size(); i++){
                                System.out.print("Cliente " + i + ": ");
                                System.out.print(listaClientes.get(i).getIdCliente()+"\n");
                                
                            }
                            System.out.print("Elija un cliente: ");
                            Integer client_opc = input.nextInt();
                            input.nextLine();
                            System.out.println("");
                            
                            System.out.println("Habitaciones disponibles:");
                            System.out.println(hotel_1.getHabitacionesDisponibles());
                            System.out.print("Seleccione la habitacion a reservar: ");
                            Integer hab_res = input.nextInt();
                            input.nextLine();
                            
                            Habitacion hab_reserv = new Habitacion();
                                hab_reserv.setNumeroHabitacion(hab_res);
                                hab_reserv.setPrecioNoche("precio");
                                hab_reserv.setDisponible(true);
                            
                            if (habitacionesDisponibles_h1.contains(hab_res)){
                                habitacionesDisponibles_h1.remove(hab_res);
                                
                                Reserva nueva_reserva = new Reserva(hotel_1, hab_reserv);
                                
                                System.out.println("La habitacion " + hab_res + " cuesta: $" + hab_reserv.getPrecioNoche()+"\n");
                                System.out.println("La habitación se reservó con éxito\n");
                            } else {
                                System.out.println("La habitación no está disponible o no existe.\n");
                            }  
                            
                        }
                    break;
                    
                case 5:
                    
                    break;
                    
                case 6:
                    System.out.println("Saliendo...");
                    System.exit(0);
            }
        }
    }
}