package com.mycompany.ejercicio_2_1_2a;

import java.util.ArrayList;

/**
 *
 * @author tapia
 */
public class Hotel {
    private String idHotel;
    private String nombreH;
    private ArrayList habitacionesDisponibles;

    public Hotel() {
    }

    public Hotel(String idHotel, String nombreH, ArrayList habitacionesDisponibles) {
        this.idHotel = idHotel;
        this.nombreH = nombreH;
        this.habitacionesDisponibles = habitacionesDisponibles;
    }

    public String getIdHotel() {
        return idHotel;
    }

    public void setIdHotel(String idHotel) {
        this.idHotel = idHotel;
    }

    public String getNombreH() {
        return nombreH;
    }

    public void setNombreH(String nombreH) {
        this.nombreH = nombreH;
    }

    public ArrayList getHabitacionesDisponibles() {
        return habitacionesDisponibles;
    }

    public void setHabitacionesDisponibles(ArrayList habitacionesDisponibles) {
        this.habitacionesDisponibles = habitacionesDisponibles;
    }
    
    
}
